<?php
include 'config.php'; // Include your database connection

// Get the search query from the URL parameters
$searchQuery = $_GET['searchQuery'];

// SQL query to search for players based on the Name or NickName fields
$sql = "SELECT IdPlayer, Name, NickName, ImagePlayer FROM player WHERE Name LIKE '%$searchQuery%' OR NickName LIKE '%$searchQuery%'";
$result = $connect->query($sql);

$players = array(); // Array to store matching players

// If there are results, fetch them
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $players[] = $row;
    }
}

// Return the players as JSON to the AJAX request
echo json_encode($players);
?>
    