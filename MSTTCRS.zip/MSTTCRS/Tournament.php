<?php
include 'config.php'; // Include the database connection
include 'header.php';


// SQL query to select tournament data, ordering by TournamentDate ASC for closest upcoming tournaments
$sql = "SELECT * FROM tournament ORDER BY TournamentDate ASC"; // Changed to ASC for nearest tournaments first

$result = $connect->query($sql); // Execute the query
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MSTTC - Tournament</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- FontAwesome for icons (optional) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <link rel="stylesheet" href="header&footer.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            background: linear-gradient(to right, black 30%, #d1b000);
        }

        .card {
            background-color: black;
            position: relative;
            margin: 30px auto;
            width: 100%;
            /* Make the card take full width */
            max-width: 850px;
            /* Limit the maximum width */
            height: 500px;
            /* Set a fixed height */
            overflow: hidden;
            /* Prevent content overflow */
            display: flex;
            align-items: center;
            border-radius: 20px;
            transition: transform 0.5s ease-in-out;
            /* Smooth transition */
        }

        .card:hover {
            transform: scale(0.95);
            /* Scale down the image on hover */
        }

        .card img {
            display: block;
            /* Remove extra space below images */
            width: 100%;
            /* Use 100% to fill the card */
            height: 100%;
            /* Fixed height */
            object-fit: cover;
            /* Cover the entire card */
            border-radius: 20px;
            /* Rounded corners */
            transition: transform 0.5s ease-in-out;
            /* Smooth transition */
            border: black solid;
            
        }

        .card:hover img {
            transform: scale(0.95);
            /* Scale down the image on hover */
        }

        .card-content {
            position: absolute;
            /* Overlay the text on the image */
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            /* Aligns the content to the top */
            margin-top: 50px;
            text-align: left;
            /* Aligns the text to the left */
            padding: 20px;

            /* Keep for debugging */
            margin-right: 350px;
        }


        .tournament-title {
            color: gold;
            font-size: 25px;
            font-weight: bold;
            margin: 10px 0;
            text-align: left;
            padding: 10px;
            width: 450px;
            margin-bottom: 30px;
            text-shadow: 7px 3px 5px black; /* Shadow effect for better readability */
        }

        .tournament-label,
        .tournament-info {
            color: white;
            font-size: 18px;
            margin: 10px 0;
            text-align: left;
            padding: 10px;

        }

        .tournament-link {
            color: black;
            font-size: 16px;
            background-color: gold;
            border: none;
            text-decoration: none;
            cursor: pointer;
            border-radius: 10px;
            padding: 10px 15px;
            transition: background-color 0.3s;
            max-width: fit-content;
            /* Fit content for better alignment */
            margin-top: auto;
            /* Push it to the bottom if you want spacing */
            align-self: flex-start;
            /* Align the button to the left */
            bottom: 0;
            border-radius: 10px;
            padding: 10px;
        }



        .tournament-link:hover {
            background-color: black;
            color: #d1b000;
            transform: translateY(-5px);
        }

        .countdown-timer {
            position: absolute;
            top: 15px;
            right: 15px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            font-size: 16px;
        }

        .card-content table {
            width: 130%;
            /* Make the table take the full width */
            border-collapse: collapse;
            /* Remove space between cells */
            background-color: rgba(0, 0, 0, 0.7);
            margin-bottom: 10px;
        }

        .card-content td {
            padding: 10px;
            /* Add some padding for better spacing */
            vertical-align: top;
            /* Align text to the top */
            color: white;
            /* Set text color to white */
            border: solid silver;
        }

        .tournament-label,
        .tournament-info {
            font-size: 18px;
            /* Adjust font size for labels */
        }


        @media (max-width: 768px) {
    .card {
        height: auto;
        margin: 10px 0;
        width: 100%;
        /* Ensure the card takes full width */
        max-width: none;
        /* Remove the max-width limitation for smaller screens */
    }

    .card-content {
        padding: 10px;
        text-align: left;
        margin-right: 0;
    }

    .card-content table {
        height: auto;
        width:auto;
        }

        .card-content td {
            height: auto;
        }

    .tournament-title {
        font-size: 18px;
        width: 100%;
        /* Reduce font size and make the title take full width */
    }

    .tournament-label,
    .tournament-info {
        font-size: 14px;
        margin-bottom: 5px;
        text-align: left;
        width: 100%;
        /* Ensure the content takes full width */
    }

    .tournament-link {
        width: 100%;
        padding: 10px;
        text-align: left;
        margin-top: 10px;
        font-size: 14px;
    }
    .card img {
        height: auto;
        width: 500px;
    }


    .countdown-timer {
        font-size: 12px;
        padding: 5px 10px;
    }
}

@media (max-width: 480px) {
    .card {
        height: auto;
        width: 100%;
    }

    .card img {
        height: auto;
        width: 500px;
    }

    .card-content table {
        height: auto;
        width: auto;
        }

        .card-content td {
            height: auto;
        }

    .tournament-title {
        font-size: 14px;
        height: auto;
        /* Smaller font size for title */
    }

    .tournament-label,
    .tournament-info {
        font-size: 12px;
        height: auto;
        /* Smaller font size for info */
    }

    .countdown-timer {
        font-size: 10px;
        height: auto;
        /* Smaller countdown size */
    }

    .tournament-link {
        font-size: 12px;
        height: auto;
        padding: 8px;
        /* Adjust padding and font size for smaller buttons */
    }
}


    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-custom ">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <img src="MsttcLogo-1.png" alt="Club Logo" />
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">News & Update</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Ranking.php">Ranking</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Player.php">Player</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="Tournament.php">Tournament</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="AboutUs.php">About Us</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <h1 style="text-align: center; color: white;">LATEST TOURNAMENT</h1>

    <div class="container-md">
        <div class="row  g-2">
            <div class="col-12">
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <div class="card" data-date="<?php echo $row['TournamentDate']; ?>">
                            <div class="countdown-timer">00d 00h 00m 00s</div>
                            <img src="uploads/<?php echo $row['TournamentImage']; ?>" alt="Tournament Image">
                            <div class="card-content">
                                <h1><span class="tournament-title"><?php echo $row['TournamentTitle']; ?></span></h1>
                                <table>
                                    <tr>
                                        <td><span class="tournament-label"><?php echo date('d-m-Y', strtotime($row['TournamentDate'])); ?></span></td>
                                        <td><span class="tournament-info"><?php echo $row['TournamentPlace']; ?></span></td>
                                    </tr>
                                </table>
                                <button class="tournament-link" onclick="window.open('<?php echo $row['TournamentLinkDetails']; ?>', '_blank')">More Info</button>
                            </div>

                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p style="color: white;">No tournaments available.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
 <footer class="bg-dark text-white pt-4">
  <div class="container">
      <div class="row">
          <div class="col-md-4">
              <h5>Quick Links</h5>
              <ul class="list-unstyled">
                  <li><a href="index.php" class="quick-link">News & Update</a></li>
                  <li><a href="Ranking.php" class="quick-link">Ranking</a></li>
                  <li><a href="Player.php" class="quick-link">Player</a></li>
                  <li><a href="Tournament.php" class="quick-link">Tournament</a></li>
                  <li><a href="AboutUs.php" class="quick-link">About Us</a></li>
                  <li><a href="AdminLogin.php" class="quick-link" target="_blank">Admin MSTTC</a></li>
              </ul>
          </div>
          <div class="col-md-4 text-center">
              <h5>Social Links</h5>
              <a href="https://www.facebook.com/msttc.madzam.shah.table.tannis.club" class="text-white me-2 facebook-link" target="_blank">
                  <i class="fab fa-facebook"></i>
              </a>
              <a href="https://wa.me/60129612701?text=Hello%20I%20am%20interested%20to%20know%20about%20MSTTC" class="text-white whatsapp-link" target="_blank">
                  <i class="fab fa-whatsapp"></i>
              </a>
              <br>


          </div>
          <div class="col-md-4 text-center">
              <h5>Welcome to MSTTC !</h5>
              <p>Muadzam Shah, Rompin, Pahang, Malaysia</p>
              <div style="max-width: 600px; margin: 0 auto;">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15951.053985349418!2d103.0671794!3d3.0625575!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cf097c511ab6ff%3A0x19299b117a82d0ba!2sJalan%20menuju%20Dewan%20Besar%20DARA!5e0!3m2!1sen!2smy!4v1698720180123!5m2!1sen!2smy"
                    width="400"
                    height="200"
                    style=""
                    allowfullscreen=""
                    loading="lazy">
                </iframe>
            </div>
            
            <a href="https://www.google.com/maps/place/Jalan+menuju+Dewan+Besar+DARA/@3.0625575,103.0671794,14.78z/data=!4m6!3m5!1s0x31cf097c511ab6ff:0x19299b117a82d0ba!8m2!3d3.0629458!4d103.0774027!16s%2Fg%2F11b7r767_g?entry=ttu&g_ep=EgoyMDI0MTAyNy4wIKXMDSoASAFQAw%3D%3D"
               target="_blank"
               class="btn btn-primary mt-3"
               style="font-size: 100%; text-decoration: none; border-radius: 5px; margin-top: 10px; height: 40px;">
                View on Google Maps
            </a>

            <br>

          </div>
          <hr style="margin-top: 14px;">
          <p style="text-align: center; margin-bottom: 30px;">&copy; 2024 MSTTC. All rights reserved.</p>

      </div>
  </div>
</footer>

    <script>
        // JavaScript to handle countdown timer and other functionalities
        document.addEventListener("DOMContentLoaded", function() {
            const cards = document.querySelectorAll('.card');
            cards.forEach(card => {
                const dateStr = card.getAttribute('data-date');
                const targetDate = new Date(dateStr).getTime();

                const countdown = card.querySelector('.countdown-timer');
                setInterval(() => {
                    const now = new Date().getTime();
                    const distance = targetDate - now;

                    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

                    countdown.innerHTML = `${days}d ${hours}h ${minutes}m ${seconds}s`;

                    if (distance < 0) {
                        countdown.innerHTML = "EXPIRED";
                    }
                }, 1000);
            });
        });
        
        document.querySelectorAll('.image-container').forEach(container => {
            const img = container.querySelector('img');
            const title = container.querySelector('.tournament-title');
        
            // Create a temporary canvas to analyze image brightness
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = img.naturalWidth;
            canvas.height = img.naturalHeight;
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const pixels = imageData.data;
        
            let brightness = 0;
            for (let i = 0; i < pixels.length; i += 4) {
                // Average of R, G, B
                brightness += (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
            }
            brightness /= pixels.length / 4;
        
            // Adjust text color based on brightness
            if (brightness > 128) {
                title.style.setProperty('--text-color', 'black');
            } else {
                title.style.setProperty('--text-color', 'white');
            }
        });

    </script>

</body>

</html>