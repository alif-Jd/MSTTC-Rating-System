<?php
include 'auth.php';
include "config.php";

$player = null;
$searchError = "";

// Function to render CareerType dropdown
function renderCareerType($selectedCareerType = '')
{
    $careerTypes = ['BEGINNER', 'ADVANCED', 'INTERMEDIATE', 'PROFESSIONAL'];
    $html = '<select name="CareerType" id="CareerType" required>';
    foreach ($careerTypes as $careerType) {
        $selected = ($careerType === $selectedCareerType) ? 'selected' : '';
        $html .= "<option value='$careerType' $selected>$careerType</option>";
    }
    $html .= '</select>';
    return $html;
}

// Function to render RatingPoint dropdown
function renderRatingPoint($selectedRatingPoint = '')
{
    $ratingPoints = ['INTERNATIONAL', 'STATE', 'DISTRICT'];
    $html = '<select name="RatingPoint" id="RatingPoint">';
    $html .= '<option value="">Select Tournament Grade</option>';
    foreach ($ratingPoints as $ratingPoint) {
        $selected = ($ratingPoint === $selectedRatingPoint) ? 'selected' : '';
        $html .= "<option value='$ratingPoint' $selected>$ratingPoint</option>";
    }
    $html .= '</select>';
    return $html;
}

// Check if the search form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $searchValue = trim($_POST['searchValue']);
    $searchQuery = "SELECT * FROM player WHERE IdPlayer = ? OR Name = ? OR NickName = ?";

    if ($stmt = mysqli_prepare($connect, $searchQuery)) {
        mysqli_stmt_bind_param($stmt, "sss", $searchValue, $searchValue, $searchValue);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            $player = $row;
        } else {
            $searchError = "Player not found.";
        }
        mysqli_stmt_close($stmt);
    } else {
        $searchError = "Error preparing query: " . mysqli_error($connect);
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MSTTC - Update Player</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- FontAwesome for icons (optional) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />

    <link rel="stylesheet" href="header&footerAdmin.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.8.1/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js"></script>

    <style>
        body {
            background: linear-gradient(to right, black, gold);
            font-family: Arial, sans-serif;
            color: white;
        }

        h1 {
            color: white;
            text-align: center;
            margin-bottom: 30px;
            margin-top: 10px;
        }

        .card {
            background-color: #1a1b34;
            border-radius: 15px;
            margin: 20px auto;
            padding: 20px;
            max-width: 800px;
            margin-bottom:20px;
        }

        .form-label {
            text-align: right;
            color: white;
        }

        .form-control,
        select {
            border: none;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 20px;
            font-size: 16px;
        }

        .form-control:focus,
        select:focus {
            outline: none;
            box-shadow: 0 0 5px #0097b2;
        }

        .btnUpdate {
            background-color: #009E60;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 20px;
            transition: all 0.3s ease;
            width: 100%;
            max-width: 180px;
            margin: 20px auto;
            
        }

        .btnUpdate:hover {
            background-color: darkgreen;
            transform: scale(1.05);
        }

        .btnSearch {
            background-color: #0097b2;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 20px;
            transition: all 0.3s ease;
            width: 100%;
            max-width: 180px;
        }

        .btnSearch:hover {
            background-color: darkcyan;
            transform: scale(1.05);
        }

        .image-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .player-img {
            max-width: 100%;
            max-height: 300px;
            /* Set a reasonable max height */
            width: auto;
            height: auto;
            border-radius: 10px;
            /* Slightly rounded corners */
            border: 2px solid #fff;
            /* White border for better visibility */
        }

        .lblSection {
            color: silver;
            font-size: 25px;
        }

        /* Base style for the alert */
        #alertMessage {
            max-width: 80%;
            margin: 20px auto;
            text-align: center;
            transition: opacity 1s ease;
            /* Smooth fade-out transition */
            opacity: 1;
            /* Fully visible initially */
        }

        #alertMessage.hidden {
            opacity: 0;
            /* Hidden state */
        }
    </style>
</head>

<body>

    <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container-fluid">
      <a class="navbar-brand" href="Admin.php">
        <img src="MsttcLogo-1.png" alt="Club Logo" />
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <i class="bi bi-grid-fill" style="font-size: 1.5rem; color: white;"></i>
      </button>

      <!-- Center the navbar links -->
      <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="custom-link-admin" href="Admin.php">
              <i class="bi bi-house-fill"> Home Admin</i>
            </a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="playerDropdown" role="button"
              data-bs-toggle="dropdown" aria-expanded="false">
              PLAYER
            </a>
            <ul class="dropdown-menu" aria-labelledby="playerDropdown">
              <li><a class="dropdown-item" href="RegistrationPlayer.php">Add Player</a></li>
              <li><a class="dropdown-item" href="UpdatePlayer.php">Update Player</a></li>
              <li><a class="dropdown-item" href="DeletePlayer.php">Delete Player</a></li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="newsDropdown" role="button"
              data-bs-toggle="dropdown" aria-expanded="false">
              NEWS
            </a>
            <ul class="dropdown-menu" aria-labelledby="newsDropdown">
              <li><a class="dropdown-item" href="RegistrationNews.php">Add News</a></li>
              <li><a class="dropdown-item" href="UpdateNews.php">Update News</a></li>
              <li><a class="dropdown-item" href="DeleteNews.php">Delete News</a></li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="tournamentDropdown" role="button"
              data-bs-toggle="dropdown" aria-expanded="false">
              TOURNAMENT
            </a>
            <ul class="dropdown-menu" aria-labelledby="tournamentDropdown">
              <li><a class="dropdown-item" href="RegistrationTournament.php">Add Tournament</a></li>
              <li><a class="dropdown-item" href="UpdateTournament.php">Update Tournament</a></li>
              <li><a class="dropdown-item" href="DeleteTournament.php">Delete Tournament</a></li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="aboutDropdown" role="button"
              data-bs-toggle="dropdown" aria-expanded="false">
              ABOUT US
            </a>
            <ul class="dropdown-menu" aria-labelledby="aboutDropdown">
              <li><a class="dropdown-item" href="RegistrationAboutUs.php">Add YT Link</a></li>
              <li><a class="dropdown-item" href="DeleteAboutUs.php">Delete YT Link</a></li>
            </ul>
          </li>

          <!-- Profile Icon with Dropdown -->
          <li class="nav-item dropdown text-right mt-2">
            <a href="#" class="profile-icon" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="bi bi-person-circle"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
              <li><button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#confirmLogOutModal">Log Out</button></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

    <div class="container">
        <div class="card">
            <h1>UPDATE PLAYER</h1>

            <!-- Search Form -->
            <form method="post" id="searchForm" action="UpdatePlayer.php">
                <div class="row mb-3">
                    <label for="searchValue" class="col-sm-2 col-form-label">Search Player</label>
                    <div class="col-sm-10">
                        <input type="text" name="searchValue" id="searchValue" class="form-control" placeholder="Enter Player ID" value="<?php echo isset($searchValue) ? htmlspecialchars($searchValue) : ''; ?>" required>
                        <?php if (!empty($searchError)): ?>
                            <p style="color: red;"><?php echo $searchError; ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" name="search" class="btnSearch">SEARCH</button>
                </div>

                <hr>

                <div id="alertMessage" class="alert alert-success alert-dismissible fade show" role="alert"
                    style="display: none;">
                    <strong>Success!</strong> Player Update Successfully!
                </div>
            </form>

            <?php if ($player): ?>

                <div class="image-container">
                    <?php if (isset($player['ImagePlayer']) && !empty($player['ImagePlayer'])): ?>
                        <img id="playerImage" src="<?php echo htmlspecialchars($player['ImagePlayer']); ?>" alt="Player Image" class="player-img">
                    <?php else: ?>
                        <p>No image available.</p>
                    <?php endif; ?>
                </div>

                <!-- Form to update player profile-->
                <form action="inputUpdatePlayer.php" method="post" id="updatePlayerForm" enctype="multipart/form-data">
                    <input type="hidden" name="IdPlayer" value="<?php echo htmlspecialchars($player['IdPlayer']); ?>">

                    <div class="row mb-3">
                        <label for="Name" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                            <input type="text" name="Name" id="Name" class="form-control" value="<?php echo htmlspecialchars($player['Name']); ?>" placeholder="Enter Player's Full Name" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="NickName" class="col-sm-2 col-form-label">Nickname</label>
                        <div class="col-sm-10">
                            <input type="text" name="NickName" id="NickName" class="form-control" value="<?php echo htmlspecialchars($player['NickName']); ?>" placeholder="Enter Player's Nickname" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="Age" class="col-sm-2 col-form-label">Age</label>
                        <div class="col-sm-10">
                            <input type="number" name="Age" id="Age" class="form-control" value="<?php echo htmlspecialchars($player['Age']); ?>" placeholder="Enter Player's Age" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="DominantHand" class="col-sm-2 col-form-label">Dominant Hand</label>
                        <div class="col-sm-10">
                            <select name="DominantHand" id="DominantHand" class="form-select" required>
                                <option value="Left" <?php echo ($player['DominantHand'] === 'Left') ? 'selected' : ''; ?>>Left</option>
                                <option value="Right" <?php echo ($player['DominantHand'] === 'Right') ? 'selected' : ''; ?>>Right</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="Playstyle" class="col-sm-2 col-form-label">Playstyle</label>
                        <div class="col-sm-10">
                            <select name="Playstyle" id="Playstyle" class="form-select" required>
                                <option value="The Aggressor" <?php echo ($player['Playstyle'] === 'The Aggressor') ? 'selected' : ''; ?>>The Aggressor</option>
                                <option value="The Controller" <?php echo ($player['Playstyle'] === 'The Controller') ? 'selected' : ''; ?>>The Controller</option>
                                <option value="The All-Rounder" <?php echo ($player['Playstyle'] === 'The All-Rounder') ? 'selected' : ''; ?>>The All-Rounder</option>
                                <option value="The Brick Wall" <?php echo ($player['Playstyle'] === 'The Brick Wall') ? 'selected' : ''; ?>>The Brick Wall</option>
                                <option value="The Defender" <?php echo ($player['Playstyle'] === 'The Defender') ? 'selected' : ''; ?>>The Defender</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="Blade" class="col-sm-2 col-form-label">Blade</label>
                        <div class="col-sm-10">
                            <input type="text" name="Blade" id="Blade" class="form-control" value="<?php echo htmlspecialchars($player['Blade']); ?>" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="RubberForeHand" class="col-sm-2 col-form-label">Rubber ForeHand</label>
                        <div class="col-sm-10">
                            <input type="text" name="RubberForeHand" id="RubberForeHand" class="form-control" value="<?php echo htmlspecialchars($player['RubberForeHand']); ?>" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="RubberBackHand" class="col-sm-2 col-form-label">Rubber Backhand</label>
                        <div class="col-sm-10">
                            <input type="text" name="RubberBackHand" id="RubberBackHand" class="form-control" value="<?php echo htmlspecialchars($player['RubberBackHand']); ?>" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="Grip" class="col-sm-2 col-form-label">Grip</label>
                        <div class="col-sm-10">
                            <select name="Grip" id="Grip" class="form-select" required>
                                <option value="Penhold" <?php echo ($player['Grip'] === 'Penhold') ? 'selected' : ''; ?>>Penhold</option>
                                <option value="Shakehand" <?php echo ($player['Grip'] === 'Shakehand') ? 'selected' : ''; ?>>Shakehand</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="CareerType" class="col-sm-2 col-form-label">Career Type</label>
                        <div class="col-sm-10">
                            <select name="CareerType" id="CareerType" class="form-select" required>
                                <option value="BEGINNER" <?php echo ($player['CareerType'] === 'BEGINNER') ? 'selected' : ''; ?>>BEGINNER</option>
                                <option value="ADVANCED" <?php echo ($player['CareerType'] === 'ADVANCED') ? 'selected' : ''; ?>>ADVANCED</option>
                                <option value="INTERMEDIATE" <?php echo ($player['CareerType'] === 'INTERMEDIATE') ? 'selected' : ''; ?>>INTERMEDIATE</option>
                                <option value="PROFESSIONAL" <?php echo ($player['CareerType'] === 'PROFESSIONAL') ? 'selected' : ''; ?>>PROFESSIONAL</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="ImagePlayer" class="col-sm-2 col-form-label">Image Player</label>
                        <div class="col-sm-10">
                            <input type="file" name="ImagePlayer" id="ImagePlayer" class="form-control" accept="image/*">
                        </div>
                    </div>

                    <div>
                        <img id="imagePreview" style="max-width: 100%; display: none;">
                    </div>
                    <input type="hidden" id="croppedImage" name="croppedImage"> <!-- Hidden input to hold cropped image data -->

                    <div class="row mb-3">
                        <label for="ImageRubberForeHand" class="col-sm-2 col-form-label">Image Rubber ForeHand</label>
                        <div class="col-sm-10">
                            <input type="file" name="ImageRubberForeHand" id="ImageRubberForeHand" class="form-control" accept="image/*">
                        </div>
                    </div>
                    <div>
                        <img id="rubberForeHandPreview" style="max-width: 100%; display: none;">
                    </div>
                    <input type="hidden" id="croppedRubberForeHand" name="croppedRubberForeHand">

                    <div class="row mb-3">
                        <label for="ImageRubberBackHand" class="col-sm-2 col-form-label">Image Rubber BackHand</label>
                        <div class="col-sm-10">
                            <input type="file" name="ImageRubberBackHand" id="ImageRubberBackHand" class="form-control" accept="image/*">
                        </div>
                    </div>
                    <div>
                        <img id="rubberBackHandPreview" style="max-width: 100%; display: none;">
                    </div>
                    <input type="hidden" id="croppedRubberBackHand" name="croppedRubberBackHand">

                    <div class="text-center">
                        <button type="submit" id="actualUpdateButton" name="updateProfile" class="btnUpdate">UPDATE PROFILE</button>
                    </div>
                </form>

                <hr>

                <!-- Player Points Section (Separate Form) -->
                <form action="inputUpdatePlayer.php" method="post" id="pointsUpdateForm">
                    <input type="hidden" name="IdPlayer" value="<?php echo htmlspecialchars($player['IdPlayer']); ?>">

                    <h2 style="color: silver;">Player Points Section</h2>

                    <div class="row mb-3">
                        <label for="TournamentType" class="col-sm-2 col-form-label">Tournament Grade</label>
                        <div class="col-sm-10">
                            <select name="TournamentType" id="TournamentType" class="form-select" required>
                                <option value="">Select Tournament Grade</option>
                                <option value="International">International</option>
                                <option value="States">States</option>
                                <option value="Districts">Districts</option>
                            </select>
                        </div>
                    </div>
                    
                     <div class="row mb-3">
                        <label for="PositionWin" class="col-sm-2 col-form-label">Position Win</label>
                        <div class="col-sm-10">
                            <select name="PositionWin" id="PositionWin" class="form-control"  required>
                                <option value="">Select Position Win</option>
                                <option value="1">1st</option>
                                <option value="2">2nd</option>
                                <option value="4">3-4</option>
                                <option value="8">5-8</option>
                                <option value="16">Group of 16</option>
                                <option value="32">Group of 32</option>
                                <option value="64">Group of 64</option>
                                <option value="128">Group of 128</option>
                            </select>
                        </div>
                    </div>

                    

                    <!-- Hidden submit button for pointsUpdateForm -->
                    <button type="submit" name="updatePoints" id="updatePointsButton" style="display: none;"></button>

                    <div class="text-center">
                        <button type="button" class="btnUpdate" id="showModalButton">UPDATE POINTS</button>
                    </div>
                </form>
                

            <?php endif; ?>
        </div>
    </div>

<!-- Update Confirmation Modal -->
    <div class="modal fade" id="confirmUpdateModal" tabindex="-1" aria-labelledby="confirmUpdateModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color:#1a1c35;">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmUpdateModalLabel" style="color: silver; font-weight: bold;">
                        Confirm Update?
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="background-color: white;"></button>
                </div>
                <div class="modal-body" style="color: white;">
                    You are about to update player points. Please double-check, as any updates to points cannot be undone.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" id="confirmUpdateButton">Yes, Update</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Log Out Confirmation Modal -->
<div class="modal fade" id="confirmLogOutModal" tabindex="-1" aria-labelledby="confirmLogOutModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" style="background-color:#1a1c35;">
      <div class="modal-header">
        <h5 class="modal-title" id="confirmLogOutModalLabel" style="color: silver; font-weight: bold;">Confirm Log Out</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" style="color: white;">
        Are you sure you want to log out?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
        <a href="logout.php" class="btn btn-danger" id="confirmLogOutButton">Yes, Log Out</a>
      </div>
    </div>
  </div>
</div>





    <script>
        function validateForm(event) {}

        // Function to scroll to the bottom of the page and hide alert after 3 seconds
        function scrollToBottom() {
            window.scrollTo({
                top: document.body.scrollHeight,
                behavior: 'smooth' // Smooth scrolling effect
            });

            // Check if the alert message is visible
            const alertMessage = document.getElementById('alertMessage');
            if (alertMessage.style.display === 'block') {
                setTimeout(() => {
                    alertMessage.classList.add('hidden'); // Trigger fade-out animation
                    setTimeout(() => {
                        alertMessage.style.display = 'none'; // Fully hide after fade-out
                    }, 1000); // Wait for the fade-out animation (1s) to complete
                }, 2000); // Wait 2 seconds before starting the fade-out
            }
        }

        // Show the alert message after form submission
        window.onload = function() {
            if (window.location.search.includes('status=success')) {
                const alertMessage = document.getElementById('alertMessage');
                alertMessage.style.display = 'block'; // Display the success message
                alertMessage.classList.remove('hidden'); // Ensure the alert is visible
                scrollToBottom(); // Scroll to bottom and trigger auto hide
            }
        };

        const imageInput = document.getElementById('ImagePlayer');
        const imagePreview = document.getElementById('imagePreview');
        let cropper;

        // Handle image input change
        imageInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (!file) {
                alert("No file selected.");
                return; // Exit if no file selected
            }

            const reader = new FileReader();
            reader.onload = function(e) {
                imagePreview.src = e.target.result;
                imagePreview.style.display = 'block';

                if (cropper) cropper.destroy(); // Destroy any existing cropper
                cropper = new Cropper(imagePreview, {
                    viewMode: 1,
                    autoCropArea: 1,
                    crop() {
                        const canvas = cropper.getCroppedCanvas();
                        document.getElementById('croppedImage').value = canvas.toDataURL();
                    }
                });
            };

            reader.onerror = function() {
                alert("Error reading file. Please try again.");
            };

            reader.readAsDataURL(file);
        });

        const rubberForeHandInput = document.getElementById('ImageRubberForeHand');
        const rubberForeHandPreview = document.getElementById('rubberForeHandPreview');
        let cropperRubberForeHand;

        rubberForeHandInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (!file) {
                alert("No file selected.");
                return;
            }
            const reader = new FileReader();
            reader.onload = function(e) {
                rubberForeHandPreview.src = e.target.result;
                rubberForeHandPreview.style.display = 'block';

                if (cropperRubberForeHand) cropperRubberForeHand.destroy();
                cropperRubberForeHand = new Cropper(rubberForeHandPreview, {
                    viewMode: 1,
                    autoCropArea: 1,
                    crop() {
                        const canvas = cropperRubberForeHand.getCroppedCanvas();
                        document.getElementById('croppedRubberForeHand').value = canvas.toDataURL();
                    }
                });
            };
            reader.readAsDataURL(file);
        });

        const rubberBackHandInput = document.getElementById('ImageRubberBackHand');
        const rubberBackHandPreview = document.getElementById('rubberBackHandPreview');
        let cropperRubberBackHand;

        rubberBackHandInput.addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (!file) {
                alert("No file selected.");
                return;
            }
            const reader = new FileReader();
            reader.onload = function(e) {
                rubberBackHandPreview.src = e.target.result;
                rubberBackHandPreview.style.display = 'block';

                if (cropperRubberBackHand) cropperRubberBackHand.destroy();
                cropperRubberBackHand = new Cropper(rubberBackHandPreview, {
                    viewMode: 1,
                    autoCropArea: 1,
                    crop() {
                        const canvas = cropperRubberBackHand.getCroppedCanvas();
                        document.getElementById('croppedRubberBackHand').value = canvas.toDataURL();
                    }
                });
            };
            reader.readAsDataURL(file);
        });


        // Handle search form submission
        const searchForm = document.getElementById('searchForm');
        searchForm.addEventListener('submit', function(event) {
            // Allow search without cropping
            // Clear cropper and image preview
            if (cropper) {
                cropper.destroy(); // Destroy the cropper on search
                cropper = null; // Reset the cropper variable
            }
            imagePreview.style.display = 'none'; // Hide the image preview
            document.getElementById('croppedImage').value = ''; // Clear the cropped image input
        });


        // Show modal when Update Points button is clicked
        document.getElementById('showModalButton').addEventListener('click', function() {
            const tournamentType = document.getElementById('TournamentType').value;
            const positionWin = document.getElementById('PositionWin').value;

            if (tournamentType && positionWin) {
                const updateModal = new bootstrap.Modal(document.getElementById('confirmUpdateModal'));
                updateModal.show(); // Show the confirmation modal
            } else {
                alert("Please fill in both Tournament Grade and Position Win before updating.");
            }
        });

        // Submit the pointsUpdateForm when modal confirmation button is clicked
        document.getElementById('confirmUpdateButton').addEventListener('click', function() {
            document.getElementById('updatePointsButton').click(); // Trigger the hidden submit button
        });
    </script>
</body>

</html>