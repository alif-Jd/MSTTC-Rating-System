<?php
include 'config.php'; // Include the database connection

// Get the type of data requested (player, news, or tournament)
$type = $_GET['type'];

if ($type == 'player') {
    // Query for player data
    $player_sql = "SELECT * FROM player";
    $player_result = $connect->query($player_sql);

    echo "<h2>Player Data</h2>";
    echo "<table class='table table-striped table-dark'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>NickName</th>
                    <th>Age</th>
                    <th>Carrer Type</th>
                </tr>
            </thead>
            <tbody>";
    if ($player_result->num_rows > 0) {
        while ($row = $player_result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["IdPlayer"] . "</td>
                    <td>" . $row["Name"] . "</td>
                    <td>" . $row["NickName"] . "</td>
                    <td>" . $row["Age"] . "</td>
                    <td>" . $row["CareerType"] . "</td>
                </tr>";
        }
    } else {
        echo "<tr><td colspan='10'>No player data found.</td></tr>";
    }
    echo "</tbody></table>";

  // Add button link to CartPlayer.php after the table
echo "<div class='d-flex justify-content-center mt-3'>
<a href='ChartPlayer.php' class='btn btn-primary custom-btn'>View Player Chart</a>
</div>";

  
} elseif ($type == 'news') {
    // Query for news data
    $news_sql = "SELECT IdNews, NewsTitle, ShortDescription, NewsDescription, NewsDate, NewsPicture, NewsLink FROM news";
    $news_result = $connect->query($news_sql);

    echo "<h2>News Data</h2>";
    echo "<table class='table table-striped table-dark'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>NewsDate</th>
                </tr>
            </thead>
            <tbody>";
    if ($news_result->num_rows > 0) {
        while ($row = $news_result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["IdNews"] . "</td>
                    <td>" . $row["NewsTitle"] . "</td>
                    <td>" . $row["NewsDate"] . "</td>
                </tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No news data found.</td></tr>";
    }
    echo "</tbody></table>";
} elseif ($type == 'tournament') {
    // Query for tournament data
    $tournament_sql = "SELECT IdTournament, TournamentTitle, TournamentPlace, TournamentDate, TournamentImage, TournamentLinkDetails FROM tournament";
    $tournament_result = $connect->query($tournament_sql);

    echo "<h2>Tournament Data</h2>";
    echo "<table class='table table-striped table-dark'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Place</th>
                </tr>
            </thead>
            <tbody>";
    if ($tournament_result->num_rows > 0) {
        while ($row = $tournament_result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["IdTournament"] . "</td>
                    <td>" . $row["TournamentTitle"] . "</td>
                    <td>" . $row["TournamentDate"] . "</td>
                    <td>" . $row["TournamentPlace"] . "</td>
                </tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No tournament data found.</td></tr>";
    }
    echo "</tbody></table>";
} elseif ($type == 'aboutus') {
    // Query for tournament data
    $aboutus_sql = "SELECT IdYoutube, YoutubeTitle, YoutubeLink FROM aboutus";
    $aboutus_result = $connect->query($aboutus_sql);

    echo "<h2>About Us Data</h2>";
    echo "<table class='table table-striped table-dark'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                </tr>
            </thead>
            <tbody>";
    if ($aboutus_result->num_rows > 0) {
        while ($row = $aboutus_result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["IdYoutube"] . "</td>
                    <td>" . $row["YoutubeTitle"] . "</td>
                </tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No youtube data found.</td></tr>";
    }
    echo "</tbody></table>";
}

// Close the connection
$connect->close();
